-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 13. Nov 2018 um 12:02
-- Server-Version: 10.1.32-MariaDB
-- PHP-Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `musik`
--
DROP DATABASE IF EXISTS `musik`;
CREATE DATABASE IF NOT EXISTS `musik` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `musik`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `artist`
--

CREATE TABLE `artist` (
  `id` int(11) NOT NULL,
  `artist` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `artist`
--

INSERT INTO `artist` (`id`, `artist`) VALUES
(1, 'Beatles'),
(2, 'Eric Clapton'),
(3, 'Pat Metheny'),
(4, 'Van Morrison'),
(5, 'Rolling Stones'),
(6, 'Roxette');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `cd`
--

CREATE TABLE `cd` (
  `id` int(11) NOT NULL,
  `album` varchar(30) NOT NULL,
  `id_artist` int(11) NOT NULL,
  `id_genre` int(11) NOT NULL,
  `jahr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `cd`
--

INSERT INTO `cd` (`id`, `album`, `id_artist`, `id_genre`, `jahr`) VALUES
(1, 'Blue Album ', 1, 1, 1970),
(2, 'Red Album ', 1, 1, 1966),
(3, 'Unplugged', 2, 2, 1992),
(4, 'Riding With the King', 2, 3, 1992),
(5, 'Travels', 3, 4, 1986),
(6, 'Still on Top', 4, 3, 2007),
(7, 'Sticky Fingers', 5, 1, 1971),
(8, 'Have a Nice Day', 6, 2, 1999);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `genre`
--

CREATE TABLE `genre` (
  `id` int(11) NOT NULL,
  `genre` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `genre`
--

INSERT INTO `genre` (`id`, `genre`) VALUES
(1, 'Rock'),
(2, 'Pop'),
(3, 'Blues'),
(4, 'Jazz');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `artist`
--
ALTER TABLE `artist`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `cd`
--
ALTER TABLE `cd`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
